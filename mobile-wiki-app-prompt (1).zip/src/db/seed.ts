import { db } from "./index";
import { worlds, articles, articleLinks, mapMarkers, timelineEvents, promptTemplates } from "./schema";
import { SEED_WORLDS, SEED_ARTICLES, SEED_MAP_MARKERS, SEED_TIMELINES, SEED_PROMPTS } from "./seed-data";
import { count } from "drizzle-orm";

export async function ensureDatabaseSeeded() {
  try {
    const worldCount = await db.select({ value: count() }).from(worlds);
    if (Number(worldCount[0]?.value || 0) > 0) {
      return;
    }

    console.log("Seeding database with rich Wiki/Obsidian/WorldAnvil data...");

    // Insert Worlds
    for (const w of SEED_WORLDS) {
      await db.insert(worlds).values(w).onConflictDoNothing();
    }

    // Insert Articles
    for (const art of SEED_ARTICLES) {
      await db.insert(articles).values({
        worldSlug: art.worldSlug,
        slug: art.slug,
        title: art.title,
        category: art.category,
        infobox: art.infobox,
        markdownContent: art.markdownContent,
        excerpt: art.excerpt,
        tags: art.tags,
        isFeatured: art.isFeatured,
        views: art.views,
      }).onConflictDoNothing();

      // Extract wikilinks from content [[slug]]
      const matches = art.markdownContent.matchAll(/\[\[([a-zA-Z0-9_-]+)(?:\|.*?)?\]\]/g);
      for (const m of matches) {
        const targetSlug = m[1].toLowerCase();
        await db.insert(articleLinks).values({
          worldSlug: art.worldSlug,
          sourceSlug: art.slug,
          targetSlug: targetSlug,
        }).onConflictDoNothing();
      }
    }

    // Insert Map Markers
    for (const marker of SEED_MAP_MARKERS) {
      await db.insert(mapMarkers).values(marker).onConflictDoNothing();
    }

    // Insert Timelines
    for (const t of SEED_TIMELINES) {
      await db.insert(timelineEvents).values(t).onConflictDoNothing();
    }

    // Insert Prompts
    for (const p of SEED_PROMPTS) {
      await db.insert(promptTemplates).values(p).onConflictDoNothing();
    }

    console.log("Seeding completed successfully!");
  } catch (err) {
    console.error("Error in ensureDatabaseSeeded:", err);
  }
}
