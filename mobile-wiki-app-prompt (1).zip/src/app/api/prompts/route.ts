import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { promptTemplates } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const prompts = await db.select().from(promptTemplates);
    return NextResponse.json({ success: true, prompts });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await request.json();
    const { category, title, framework, description, prompt, tags } = body;

    const created = await db
      .insert(promptTemplates)
      .values({
        category: category || "Custom Prompt",
        title,
        framework: framework || "React Native Expo",
        description: description || "Custom developer blueprint prompt",
        prompt,
        tags: tags || [],
      })
      .returning();

    return NextResponse.json({ success: true, prompt: created[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
