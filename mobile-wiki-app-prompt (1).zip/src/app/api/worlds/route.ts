import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { worlds } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const data = await db.select().from(worlds);
    return NextResponse.json({ success: true, worlds: data });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await request.json();
    const { slug, name, tagline, description, themeColor, bannerUrl, icon } = body;

    const created = await db
      .insert(worlds)
      .values({
        slug,
        name,
        tagline,
        description,
        themeColor: themeColor || "#6366f1",
        bannerUrl,
        icon: icon || "Globe",
      })
      .returning();

    return NextResponse.json({ success: true, world: created[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
