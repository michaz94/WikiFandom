import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { timelineEvents } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq, asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world") || "aethelgard";

    const events = await db
      .select()
      .from(timelineEvents)
      .where(eq(timelineEvents.worldSlug, worldSlug))
      .orderBy(asc(timelineEvents.orderIndex));

    return NextResponse.json({ success: true, events });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await request.json();
    const { worldSlug, year, era, title, description, articleSlug, orderIndex } = body;

    const created = await db
      .insert(timelineEvents)
      .values({
        worldSlug,
        year,
        era,
        title,
        description,
        articleSlug,
        orderIndex: Number(orderIndex || 0),
      })
      .returning();

    return NextResponse.json({ success: true, event: created[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
