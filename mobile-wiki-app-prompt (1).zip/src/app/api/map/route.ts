import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { mapMarkers } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world") || "aethelgard";

    const markers = await db
      .select()
      .from(mapMarkers)
      .where(eq(mapMarkers.worldSlug, worldSlug));

    return NextResponse.json({ success: true, markers });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await request.json();
    const { worldSlug, title, type, x, y, articleSlug, description } = body;

    const created = await db
      .insert(mapMarkers)
      .values({
        worldSlug,
        title,
        type: type || "landmark",
        x: Number(x),
        y: Number(y),
        articleSlug,
        description,
      })
      .returning();

    return NextResponse.json({ success: true, marker: created[0] });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
