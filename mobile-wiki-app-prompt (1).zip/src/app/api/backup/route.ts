import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { worlds, articles, articleLinks, mapMarkers, timelineEvents } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

/** GET : dump complet du vault (tous projets confondus). */
export async function GET() {
  try {
    await ensureDatabaseSeeded();
    const [w, a, l, m, t] = await Promise.all([
      db.select().from(worlds),
      db.select().from(articles),
      db.select().from(articleLinks),
      db.select().from(mapMarkers),
      db.select().from(timelineEvents),
    ]);
    return NextResponse.json({ success: true, dump: { worlds: w, articles: a, links: l, markers: m, timelines: t } });
  } catch (e: any) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}

/** POST : restauration d'un dump (remplace tout le vault). */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const dump = body.dump || body;
    if (!dump || !Array.isArray(dump.worlds) || !Array.isArray(dump.articles)) {
      return NextResponse.json({ success: false, error: "Format de sauvegarde invalide." }, { status: 400 });
    }

    // Purge (enfants d'abord)
    await db.delete(articleLinks);
    await db.delete(mapMarkers);
    await db.delete(timelineEvents);
    await db.delete(articles);
    await db.delete(worlds);

    for (const w of dump.worlds) {
      await db.insert(worlds).values({
        slug: w.slug,
        name: w.name,
        tagline: w.tagline,
        description: w.description,
        themeColor: w.themeColor,
        bannerUrl: w.bannerUrl,
        icon: w.icon,
        iconEmoji: w.iconEmoji,
      });
    }

    for (const a of dump.articles) {
      await db.insert(articles).values({
        worldSlug: a.worldSlug,
        slug: a.slug,
        title: a.title,
        category: a.category,
        infobox: a.infobox,
        markdownContent: a.markdownContent,
        excerpt: a.excerpt,
        tags: a.tags,
        isFeatured: a.isFeatured,
        views: a.views,
      });
    }

    for (const l of dump.links || []) {
      await db.insert(articleLinks).values({
        worldSlug: l.worldSlug,
        sourceSlug: l.sourceSlug,
        targetSlug: l.targetSlug,
      });
    }

    for (const m of dump.markers || []) {
      await db.insert(mapMarkers).values({
        worldSlug: m.worldSlug,
        title: m.title,
        type: m.type,
        x: m.x,
        y: m.y,
        articleSlug: m.articleSlug,
        description: m.description,
      });
    }

    for (const t of dump.timelines || []) {
      await db.insert(timelineEvents).values({
        worldSlug: t.worldSlug,
        year: t.year,
        era: t.era,
        title: t.title,
        description: t.description,
        articleSlug: t.articleSlug,
        orderIndex: t.orderIndex,
      });
    }

    return NextResponse.json({
      success: true,
      counts: {
        worlds: dump.worlds.length,
        articles: dump.articles.length,
        markers: (dump.markers || []).length,
        timelines: (dump.timelines || []).length,
      },
    });
  } catch (e: any) {
    return NextResponse.json({ success: false, error: e.message }, { status: 500 });
  }
}
