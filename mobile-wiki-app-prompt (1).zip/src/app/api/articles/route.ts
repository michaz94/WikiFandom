import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { articles, articleLinks } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq, and, or, ilike, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world");
    const category = searchParams.get("category");
    const search = searchParams.get("search");

    const conditions: any[] = [];
    if (worldSlug) {
      conditions.push(eq(articles.worldSlug, worldSlug));
    }

    if (category && category !== "all") {
      conditions.push(eq(articles.category, category));
    }

    if (search && search.trim() !== "") {
      const query = `%${search.trim()}%`;
      conditions.push(
        or(
          ilike(articles.title, query),
          ilike(articles.markdownContent, query),
          ilike(articles.excerpt, query)
        )!
      );
    }

    const data = await db
      .select()
      .from(articles)
      .where(and(...conditions))
      .orderBy(desc(articles.views));

    return NextResponse.json({ success: true, articles: data });
  } catch (error: any) {
    console.error("Error fetching articles:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const body = await request.json();
    const { worldSlug, slug, title, category, infobox, markdownContent, excerpt, tags, isFeatured } = body;

    if (!worldSlug || !slug || !title || !markdownContent) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 });
    }

    // Check if article exists
    const existing = await db
      .select()
      .from(articles)
      .where(and(eq(articles.worldSlug, worldSlug), eq(articles.slug, slug)));

    let savedArticle;
    if (existing.length > 0) {
      const updated = await db
        .update(articles)
        .set({
          title,
          category: category || "lore",
          infobox,
          markdownContent,
          excerpt: excerpt || markdownContent.slice(0, 140) + "...",
          tags: tags || [],
          isFeatured: !!isFeatured,
          updatedAt: new Date(),
        })
        .where(eq(articles.id, existing[0].id))
        .returning();
      savedArticle = updated[0];
    } else {
      const created = await db
        .insert(articles)
        .values({
          worldSlug,
          slug,
          title,
          category: category || "lore",
          infobox,
          markdownContent,
          excerpt: excerpt || markdownContent.slice(0, 140) + "...",
          tags: tags || [],
          isFeatured: !!isFeatured,
        })
        .returning();
      savedArticle = created[0];
    }

    // Refresh wikilinks
    await db.delete(articleLinks).where(and(eq(articleLinks.worldSlug, worldSlug), eq(articleLinks.sourceSlug, slug)));
    const matches = markdownContent.matchAll(/\[\[([a-zA-Z0-9_-]+)(?:\|.*?)?\]\]/g);
    for (const m of matches) {
      const targetSlug = m[1].toLowerCase();
      await db.insert(articleLinks).values({
        worldSlug,
        sourceSlug: slug,
        targetSlug,
      }).onConflictDoNothing();
    }

    return NextResponse.json({ success: true, article: savedArticle });
  } catch (error: any) {
    console.error("Error creating/updating article:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
