import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { articles, articleLinks } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq, and, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    await ensureDatabaseSeeded();
    const { slug } = await params;
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world") || "aethelgard";

    const articleList = await db
      .select()
      .from(articles)
      .where(and(eq(articles.worldSlug, worldSlug), eq(articles.slug, slug)));

    if (articleList.length === 0) {
      return NextResponse.json({ success: false, error: "Article not found" }, { status: 404 });
    }

    const article = articleList[0];

    // Increment view count asynchronously
    await db
      .update(articles)
      .set({ views: sql`${articles.views} + 1` })
      .where(eq(articles.id, article.id));

    // Get backlinks (Obsidian feature: articles linking TO this article)
    const incomingLinks = await db
      .select({
        sourceSlug: articleLinks.sourceSlug,
      })
      .from(articleLinks)
      .where(and(eq(articleLinks.worldSlug, worldSlug), eq(articleLinks.targetSlug, slug)));

    const sourceSlugs = incomingLinks.map((l) => l.sourceSlug);
    let backlinks: any[] = [];
    if (sourceSlugs.length > 0) {
      const allBacklinkArticles = await db
        .select({
          slug: articles.slug,
          title: articles.title,
          category: articles.category,
          excerpt: articles.excerpt,
        })
        .from(articles)
        .where(eq(articles.worldSlug, worldSlug));

      backlinks = allBacklinkArticles.filter((a) => sourceSlugs.includes(a.slug));
    }

    // Get outgoing links (articles this one links TO)
    const outgoingLinks = await db
      .select({
        targetSlug: articleLinks.targetSlug,
      })
      .from(articleLinks)
      .where(and(eq(articleLinks.worldSlug, worldSlug), eq(articleLinks.sourceSlug, slug)));

    return NextResponse.json({
      success: true,
      article,
      backlinks,
      outgoingLinks: outgoingLinks.map((o) => o.targetSlug),
    });
  } catch (error: any) {
    console.error("Error fetching article slug:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world") || "aethelgard";

    await db.delete(articleLinks).where(and(eq(articleLinks.worldSlug, worldSlug), eq(articleLinks.sourceSlug, slug)));
    await db.delete(articleLinks).where(and(eq(articleLinks.worldSlug, worldSlug), eq(articleLinks.targetSlug, slug)));
    await db.delete(articles).where(and(eq(articles.worldSlug, worldSlug), eq(articles.slug, slug)));

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
