import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { articles, articleLinks } from "@/db/schema";
import { ensureDatabaseSeeded } from "@/db/seed";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureDatabaseSeeded();
    const { searchParams } = new URL(request.url);
    const worldSlug = searchParams.get("world") || "aethelgard";

    const allArticles = await db
      .select({
        id: articles.slug,
        title: articles.title,
        category: articles.category,
        excerpt: articles.excerpt,
        views: articles.views,
        tags: articles.tags,
      })
      .from(articles)
      .where(eq(articles.worldSlug, worldSlug));

    const links = await db
      .select({
        source: articleLinks.sourceSlug,
        target: articleLinks.targetSlug,
      })
      .from(articleLinks)
      .where(eq(articleLinks.worldSlug, worldSlug));

    // Filter links to only those where target exists in articles
    const articleSlugSet = new Set(allArticles.map((a) => a.id));
    const validLinks = links.filter((l) => articleSlugSet.has(l.source) && articleSlugSet.has(l.target));

    // Calculate degree (connection count) for each node to size them like Obsidian
    const degreeMap: Record<string, number> = {};
    for (const l of validLinks) {
      degreeMap[l.source] = (degreeMap[l.source] || 0) + 1;
      degreeMap[l.target] = (degreeMap[l.target] || 0) + 1;
    }

    const nodes = allArticles.map((a) => ({
      ...a,
      connections: degreeMap[a.id] || 0,
    }));

    return NextResponse.json({
      success: true,
      graph: {
        nodes,
        links: validLinks,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
